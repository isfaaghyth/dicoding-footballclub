package isfaaghyth.app.fotballclub.ui.main.fragment.favorites

import isfaaghyth.app.fotballclub.base.BaseView

/**
 * Created by isfaaghyth on 9/21/18.
 * github: @isfaaghyth
 */
interface FavoritesView : BaseView {
}