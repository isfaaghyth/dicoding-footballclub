package isfaaghyth.app.fotballclub.data.model

/**
 * Created by isfaaghyth on 9/19/18.
 * github: @isfaaghyth
 */
data class Teams(val teams: List<Team>)