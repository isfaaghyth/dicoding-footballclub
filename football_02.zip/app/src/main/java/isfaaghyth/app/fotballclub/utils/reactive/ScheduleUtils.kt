package isfaaghyth.app.fotballclub.utils.reactive

/**
 * Created by isfaaghyth on 9/19/18.
 * github: @isfaaghyth
 */
object ScheduleUtils {
    fun <T> set(): MainScheduler<T> = MainScheduler()
}