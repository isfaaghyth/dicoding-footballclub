package isfaaghyth.app.fotballclub.data.model

/**
 * Created by isfaaghyth on 9/19/18.
 * github: @isfaaghyth
 */
data class MatchEvent(val events: List<Match>)