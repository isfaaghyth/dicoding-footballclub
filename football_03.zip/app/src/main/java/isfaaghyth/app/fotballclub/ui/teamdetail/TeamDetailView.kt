package isfaaghyth.app.fotballclub.ui.teamdetail

import isfaaghyth.app.fotballclub.base.BaseView

/**
 * Created by isfaaghyth on 9/20/18.
 * github: @isfaaghyth
 */
interface TeamDetailView : BaseView {
}