package isfaaghyth.app.fotballclub.data.model

/**
 * Created by isfaaghyth on 9/19/18.
 * github: @isfaaghyth
 */
data class TeamRepository(val teams: List<Team>)