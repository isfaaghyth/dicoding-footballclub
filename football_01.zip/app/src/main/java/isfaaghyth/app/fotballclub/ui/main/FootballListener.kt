package isfaaghyth.app.fotballclub.ui.main

import isfaaghyth.app.fotballclub.data.model.Club

/**
 * Created by isfaaghyth on 9/17/18.
 * github: @isfaaghyth
 */
interface FootballListener {
    fun onClicked(club: Club)
}