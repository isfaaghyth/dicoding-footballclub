package isfaaghyth.app.fotballclub.ui.main.fragment.matches

import isfaaghyth.app.fotballclub.base.BaseView

/**
 * Created by isfaaghyth on 9/21/18.
 * github: @isfaaghyth
 */
interface MatchesView : BaseView {
}