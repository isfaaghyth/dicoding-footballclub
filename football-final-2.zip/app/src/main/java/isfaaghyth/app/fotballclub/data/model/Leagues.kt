package isfaaghyth.app.fotballclub.data.model

/**
 * Created by isfaaghyth on 9/21/18.
 * github: @isfaaghyth
 */
data class Leagues(val leagues: List<League>)